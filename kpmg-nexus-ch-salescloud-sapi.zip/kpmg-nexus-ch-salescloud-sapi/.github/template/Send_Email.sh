echo "Sending Email"
# Parse input parameters
while getopts f:t:s:d: flag
do
    case "${flag}" in
        f) from=${OPTARG};;
        t) to=${OPTARG};;
        s) subject=${OPTARG};;
        d) status=${OPTARG};;
    esac
done

# full email subject 
FULLSUBJECT="${GITHUB_REF_NAME}- ${subject} - ${status}"


BODY="Hi.\n\n"
BODY+="This is to notify you that Execution of ${GITHUB_REF_NAME} -${subject} was ${status} . Below is the Job details\n\n"
BODY+="Repository: ${GITHUB_REPOSITORY} \n"
BODY+="Branch: ${GITHUB_REF_NAME} \n"
BODY+="Initiator: ${GITHUB_ACTOR} \n"
BODY+="Workflow No: ${GITHUB_RUN_NUMBER} \n"
BODY+="Workflow URL: $GITHUB_SERVER_URL/$GITHUB_REPOSITORY/actions/runs/$GITHUB_RUN_ID \n\n\n"
BODY+="Best Regards\n"
BODY+="DevOps"


echo -e "$BODY" | mail -s "$FULLSUBJECT" -r "$from" "$to"
