rm -rf Mulesoft.fpr
echo "PATH="/opt/Fortify_SCA/y/bin:$PATH"" >> ~/.bashrc
source ~/.bashrc
sourceanalyzer -64 -Xmx4384M -Xms600M -Xss24M -b "MuleSoft-kpmg-nexus-ch-salescloud-sapi" -clean
sourceanalyzer -64 -Xmx4384M -Xms600M -Xss24M -b "MuleSoft-kpmg-nexus-ch-salescloud-sapi" ../src
sourceanalyzer -64 -Xmx4384M -Xms600M -Xss24M -b "MuleSoft-kpmg-nexus-ch-salescloud-sapi" -scan -format fpr -f MuleSoft-kpmg-nexus-ch-salescloud-sapi.fpr
fortifyclient -url https://fortify.us.kworld.kpmg.com/ssc/ -authtoken $1  uploadFPR -file MuleSoft-kpmg-nexus-ch-salescloud-sapi.fpr -applicationVersionID "12379"
